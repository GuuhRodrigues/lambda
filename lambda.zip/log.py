def function_log(mensagem):
    return print('Adicionando log via função, event: ', mensagem)
